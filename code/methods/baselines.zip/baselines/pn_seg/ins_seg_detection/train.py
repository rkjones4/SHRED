import argparse
from datetime import datetime
import h5py
import numpy as np
import tensorflow as tf
import importlib
import os
import sys
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = BASE_DIR
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'models'))
sys.path.append(os.path.join(ROOT_DIR, '../utils'))
import provider
import tf_util
import random
import json
from commons import check_mkdir, force_mkdir
from geometry_utils import *
from progressbar import ProgressBar
from subprocess import call

parser = argparse.ArgumentParser()
parser.add_argument('--data_path', '-dp', type=str)
parser.add_argument('--num_ins', type=int,  help='Max Number of Instance [default: 200]')
parser.add_argument('--num_point', type=int, help='Point Number [default: 10000]')

parser.add_argument('--gpu', type=int, default=0, help='GPU to use [default: GPU 0]')
parser.add_argument('--model', type=str, default='pn_seg_model', help='Model name [default: model]')
parser.add_argument('--max_epoch', type=int, default=1001, help='Epoch to run [default: 251]')
parser.add_argument('--batch_size', type=int, default=12, help='Batch Size during training [default: 12]')
parser.add_argument('--learning_rate', type=float, default=0.001, help='Initial learning rate [default: 0.001]')
parser.add_argument('--momentum', type=float, default=0.9, help='Initial learning rate [default: 0.9]')
parser.add_argument('--optimizer', default='adam', help='adam or momentum [default: adam]')
parser.add_argument('--ins_loss_weight', type=float, default=1.0, help='Instance Segmentation Loss Weight [default: 1.0]')
parser.add_argument('--l21_norm_loss_weight', type=float, default=0.1, help='l21 Norm Loss Weight [default: 0.1]')
parser.add_argument('--conf_loss_weight', type=float, default=1.0, help='Conf Loss Weight [default: 1.0]')
parser.add_argument('--num_train_epoch_per_test', type=int, default=5, help='Number of train epochs per testing [default: 5]')
FLAGS = parser.parse_args()

ES_PATIENCE = 20
ES_THRESH = 0.001


BATCH_SIZE = FLAGS.batch_size
NUM_POINT = FLAGS.num_point
MAX_EPOCH = FLAGS.max_epoch
BASE_LEARNING_RATE = FLAGS.learning_rate
GPU_INDEX = FLAGS.gpu
MOMENTUM = FLAGS.momentum
OPTIMIZER = FLAGS.optimizer

MODEL = importlib.import_module(FLAGS.model) # import network module
MODEL_FILE = os.path.join(ROOT_DIR, 'models', FLAGS.model+'.py')
LOG_DIR = FLAGS.data_path
force_mkdir(LOG_DIR)
CKPT_DIR = os.path.join(LOG_DIR, 'trained_models')
force_mkdir(CKPT_DIR)

os.system('cp %s %s' % (MODEL_FILE, LOG_DIR)) # bkp of model def
os.system('cp %s %s' % (__file__, LOG_DIR)) # bkp of train procedure
LOG_FOUT = open(os.path.join(LOG_DIR, 'log_train.txt'), 'w')
LOG_FOUT.write(str(FLAGS)+'\n')

def log_string(out_str):
    LOG_FOUT.write(out_str+'\n')
    LOG_FOUT.flush()
    print(out_str)

DECAY_RATE = 0.8
DECAY_STEP = 40000.0
log_string('lr_decay_rate: %f, lr_decay_step: %f' % (DECAY_RATE, DECAY_STEP))

BN_INIT_DECAY = 0.5
BN_DECAY_DECAY_RATE = 0.5
BN_DECAY_DECAY_STEP = float(DECAY_STEP)
BN_DECAY_CLIP = 0.99

data_in_dir = f'{FLAGS.data_path}/'
train_h5_fn_list = [f'train.h5']        
val_h5_fn_list = [f'val.h5']

LOAD_SIZE = 500

NUM_INS = FLAGS.num_ins
print('Number of Instances: ', NUM_INS)

def get_learning_rate(batch):
    learning_rate = tf.train.exponential_decay(
                        BASE_LEARNING_RATE,  # Base learning rate.
                        batch * BATCH_SIZE,  # Current index into the dataset.
                        DECAY_STEP,          # Decay step.
                        DECAY_RATE,          # Decay rate.
                        staircase=True)
    learning_rate = tf.maximum(learning_rate, 0.00001) # CLIP THE LEARNING RATE!
    return learning_rate        

def get_bn_decay(batch):
    bn_momentum = tf.train.exponential_decay(
                      BN_INIT_DECAY,
                      batch*BATCH_SIZE,
                      BN_DECAY_DECAY_STEP,
                      BN_DECAY_DECAY_RATE,
                      staircase=True)
    bn_decay = tf.minimum(BN_DECAY_CLIP, 1 - bn_momentum)
    return bn_decay

def train():
    with tf.Graph().as_default():
        with tf.device('/gpu:'+str(GPU_INDEX)):
            pc_pl, gt_mask_pl, gt_valid_pl = MODEL.placeholder_inputs(BATCH_SIZE, NUM_POINT, NUM_INS)
            is_training_pl = tf.placeholder(tf.bool, shape=())
            
            # Note the global_step=batch parameter to minimize. 
            # That tells the optimizer to helpfully increment the 'batch' parameter
            # for you every time it trains.
            batch = tf.get_variable('batch', [],
                initializer=tf.constant_initializer(0), trainable=False)
            bn_decay = get_bn_decay(batch)
            tf.summary.scalar('bn_decay', bn_decay)

            # Get model and loss 
            mask_pred, conf_pred, end_points = MODEL.get_model(
                pc_pl,  NUM_INS, is_training_pl, bn_decay=bn_decay
            )
            
            ins_loss, end_points = MODEL.get_ins_loss(mask_pred, gt_mask_pl, gt_valid_pl, end_points)
            tf.summary.scalar('ins_loss', ins_loss)

            l21_norm_loss, end_points = MODEL.get_l21_norm(mask_pred, end_points)
            tf.summary.scalar('l21_norm_loss', l21_norm_loss)

            conf_loss, end_points = MODEL.get_conf_loss(conf_pred, gt_valid_pl, end_points)
            tf.summary.scalar('conf_loss', conf_loss)

            total_loss = FLAGS.ins_loss_weight * ins_loss + \
                    FLAGS.l21_norm_loss_weight * l21_norm_loss + \
                    FLAGS.conf_loss_weight * conf_loss
            
            tf.summary.scalar('total_loss', total_loss)

            print("--- Get training operator")
            # Get training operator
            learning_rate = get_learning_rate(batch)
            tf.summary.scalar('learning_rate', learning_rate)
            if OPTIMIZER == 'momentum':
                optimizer = tf.train.MomentumOptimizer(learning_rate, momentum=MOMENTUM)
            elif OPTIMIZER == 'adam':
                optimizer = tf.train.AdamOptimizer(learning_rate)
            train_op = optimizer.minimize(total_loss, global_step=batch)
            
            # Add ops to save and restore all the variables.
            saver = tf.train.Saver(max_to_keep=50)
        
        # Create a session
        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True
        config.allow_soft_placement = True
        config.log_device_placement = False
        sess = tf.Session(config=config)

        # Add summary writers
        merged = tf.summary.merge_all()
        train_writer = tf.summary.FileWriter(os.path.join(LOG_DIR, 'train'), sess.graph)
        test_writer = tf.summary.FileWriter(os.path.join(LOG_DIR, 'test'), sess.graph)

        # Init variables
        init = tf.global_variables_initializer()
        sess.run(init)

        ops = {'pc_pl': pc_pl,
               'gt_mask_pl': gt_mask_pl,
               'gt_valid_pl': gt_valid_pl,
               'is_training_pl': is_training_pl,
               'mask_pred': mask_pred,
               'conf_pred': conf_pred,
               'ins_loss': ins_loss,
               'conf_loss': conf_loss,
               'l21_norm_loss': l21_norm_loss,
               'loss': total_loss,
               'train_op': train_op,
               'merged': merged,
               'step': batch,
               'learning_rate': learning_rate,
               'bn_decay': bn_decay,
               'end_points': end_points}

        best_epoch = 0
        best_loss = 1e8
        
        for epoch in range(MAX_EPOCH):
            log_string('**** EPOCH %03d ****' % (epoch))
            sys.stdout.flush()
             
            train_one_epoch(sess, ops, train_writer, epoch)

            if (epoch+1) % FLAGS.num_train_epoch_per_test == 0:
                eval_loss = eval_one_epoch(sess, ops, test_writer, epoch)

                if (eval_loss + ES_THRESH) < best_loss:
                
                    save_path = saver.save(sess, os.path.join(CKPT_DIR, "best.ckpt"))
                    log_string("Model saved in file: %s" % save_path)

                    best_epoch = epoch
                    best_loss = eval_loss

                if epoch - best_epoch > ES_PATIENCE:
                    print("STOPPING EARLY")
                    break
                    
def get_num_in_h5(fn):
    with h5py.File(fn, 'r') as fin:
        return fin['gt_valid'].shape[0]
    
                
def load_h5(fn, start):
    with h5py.File(fn, 'r') as fin:
        
        pts = fin['pts'][start:start+LOAD_SIZE]
        gt_mask = fin['gt_mask'][start:start+LOAD_SIZE]
        gt_valid = fin['gt_valid'][start:start+LOAD_SIZE]        
        
        return pts, gt_mask, gt_valid

def load_json(fn):
    with open(fn, 'r') as fin:
        return json.load(fin)

def load_data(fn, start):
    pts, gt_mask, gt_valid = load_h5(fn, start)
    return pts, gt_mask, gt_valid

def train_one_epoch(sess, ops, writer, epoch):
    """ ops: dict mapping from string to tf ops """
    is_training = True
    
    log_string(str(datetime.now()))

    # shuffle training files order
    random.shuffle(train_h5_fn_list)

    assert(len(train_h5_fn_list) == 1)
    item = train_h5_fn_list[0]

    cur_h5_fn = os.path.join(data_in_dir, item)
    
    num_in_h5 = get_num_in_h5(cur_h5_fn)

    for start_num in range(0, num_in_h5, LOAD_SIZE):
        
        print(f'Reading data from {cur_h5_fn} | {start_num}')
        
        pts, gt_mask, gt_valid = load_data(cur_h5_fn, start_num)
        
        # shuffle data order
        n_shape = pts.shape[0]
        idx = np.arange(n_shape)
        np.random.shuffle(idx)
        
        pts = pts[idx, ...]
        gt_mask = gt_mask[idx, ...]
        gt_valid = gt_valid[idx, ...]

        # data augmentation to pts
        pts = provider.jitter_point_cloud(pts)
        pts = provider.shift_point_cloud(pts)
        pts = provider.random_scale_point_cloud(pts)
        pts = provider.rotate_perturbation_point_cloud(pts)

        num_batch = n_shape // BATCH_SIZE
        for i in range(num_batch):
            start_idx = i * BATCH_SIZE
            end_idx = (i + 1) * BATCH_SIZE

            cur_pts = pts[start_idx: end_idx, ...]
            cur_gt_mask = gt_mask[start_idx: end_idx, ...]
            cur_gt_valid = gt_valid[start_idx: end_idx, ...]

            feed_dict = {ops['pc_pl']: cur_pts,
                         ops['gt_mask_pl']: cur_gt_mask,
                         ops['gt_valid_pl']: cur_gt_valid,
                         ops['is_training_pl']: is_training}

            summary, step, _, lr_val, bn_decay_val, ins_loss_val,  l21_norm_loss_val, conf_loss_val, loss_val, \
                    mask_pred_val = sess.run([ops['merged'], ops['step'], ops['train_op'], ops['learning_rate'], ops['bn_decay'], \
                        ops['ins_loss'], ops['l21_norm_loss'], ops['conf_loss'], ops['loss'], \
                        ops['mask_pred']], feed_dict=feed_dict)

            writer.add_summary(summary, step)

            log_string('[Train Epoch %03d, Batch %03d, LR: %f, BN_DECAY: %f] Loss: %f = %f x %f (ins_loss) + %f x %f (l21_norm_loss) + %f x %f (conf_loss)' \
                    % (epoch, i, lr_val, bn_decay_val, loss_val, \
                    FLAGS.ins_loss_weight, ins_loss_val, \
                    FLAGS.l21_norm_loss_weight, l21_norm_loss_val, FLAGS.conf_loss_weight, conf_loss_val))


def eval_one_epoch(sess, ops, writer, epoch):
    """ ops: dict mapping from string to tf ops """
    is_training = False
    
    log_string(str(datetime.now()))

    cnt = 0; tot_loss = 0.0; tot_ins_loss = 0.0; tot_l21_norm_loss = 0.0; tot_conf_loss = 0.0;

    assert(len(val_h5_fn_list) == 1)
    item = val_h5_fn_list[0]

    cur_h5_fn = os.path.join(data_in_dir, item)
    
    num_in_h5 = get_num_in_h5(cur_h5_fn)
    
    for start_num in range(0, num_in_h5, LOAD_SIZE):
        
        pts, gt_mask, gt_valid = load_data(cur_h5_fn, start_num)
         
        n_shape = pts.shape[0]
        num_batch = int((n_shape - 1) / BATCH_SIZE) + 1

        cur_pts = np.zeros((BATCH_SIZE, NUM_POINT, 3), dtype=np.float32)
        cur_gt_mask = np.zeros((BATCH_SIZE, NUM_INS, NUM_POINT), dtype=np.float32)
        cur_gt_valid = np.zeros((BATCH_SIZE, NUM_INS), dtype=np.float32)

        for i in range(num_batch):
            start_idx = i * BATCH_SIZE
            end_idx = min((i + 1) * BATCH_SIZE, n_shape)

            cur_pts[:end_idx-start_idx, ...] = pts[start_idx: end_idx, ...]
            cur_gt_mask[:end_idx-start_idx, ...] = gt_mask[start_idx: end_idx, ...]
            cur_gt_valid[:end_idx-start_idx, ...] = gt_valid[start_idx: end_idx, ...]

            feed_dict = {ops['pc_pl']: cur_pts,
                         ops['gt_mask_pl']: cur_gt_mask,
                         ops['gt_valid_pl']: cur_gt_valid,
                         ops['is_training_pl']: is_training}

            summary, step, ins_loss_val, l21_norm_loss_val, conf_loss_val, loss_val, \
                    per_shape_l21_norm_val, \
                    mask_pred_val,  \
                    matching_idx_val, per_shape_mean_iou_val, per_shape_all_iou_val,  \
                    conf_gt, conf_pred \
             = sess.run([ops['merged'], ops['step'], \
                        ops['ins_loss'],  ops['l21_norm_loss'], ops['conf_loss'], ops['loss'], \
                        ops['end_points']['per_shape_l21_norm'], \
                        ops['mask_pred'], \
                        ops['end_points']['matching_idx'],
                        ops['end_points']['per_shape_mean_iou'], \
                        ops['end_points']['per_shape_all_iou'], \
                        ops['end_points']['per_part_conf_target'], ops['conf_pred']
                    ], feed_dict=feed_dict)

            writer.add_summary(summary, step)

            cnt += end_idx-start_idx
            tot_loss += loss_val * (end_idx-start_idx)
            tot_ins_loss += ins_loss_val * (end_idx-start_idx)
            tot_conf_loss += conf_loss_val * (end_idx-start_idx)
            tot_l21_norm_loss += l21_norm_loss_val * (end_idx-start_idx)

    avg_loss = tot_loss / cnt
    avg_ins_loss = tot_ins_loss / cnt
    avg_l21_norm_loss = tot_l21_norm_loss / cnt
    avg_conf_loss = tot_conf_loss / cnt

    log_string('[Test Epoch %03d] Average Loss: cnt: %d, %f = %f x %f (ins_loss) + %f x %f (l21_norm_loss) + %f x %f (conf_loss)' \
            % (epoch, cnt, avg_loss, \
            FLAGS.ins_loss_weight, avg_ins_loss, \
            FLAGS.l21_norm_loss_weight, avg_l21_norm_loss, FLAGS.conf_loss_weight, avg_conf_loss))

    return avg_loss

# main
log_string('pid: %s'%(str(os.getpid())))
train()
LOG_FOUT.close()

