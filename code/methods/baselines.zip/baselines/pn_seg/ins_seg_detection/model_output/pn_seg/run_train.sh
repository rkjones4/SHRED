cd methods/pn_seg/ins_seg_detection//
python3 train.py -dp model_output/m24_pn_seg --num_point 10000 --num_ins 200
