import numpy as np
import tensorflow as tf
import importlib
import os
import sys
import torch

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = BASE_DIR
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'models'))
sys.path.append(os.path.join(ROOT_DIR, '../utils'))

from geometry_utils import *

MIN_POINT_SCORE = 0.5
MIN_NUM_POINTS = 10
BATCH_SIZE = 1
GPU_INDEX = 0
MODEL = importlib.import_module('pn_seg_model') # import network module
MODEL_FILE = os.path.join(ROOT_DIR, 'models', 'pn_seg_model.py')
NUM_INS = 200
        
def pred_regions(model_path, pts):
    
    NUM_POINT = pts.shape[0]
                
    LOG_DIR = model_path
    
    CKPT_DIR = os.path.join(LOG_DIR, 'trained_models')
    
    with tf.Graph().as_default():
        with tf.device('/gpu:'+str(GPU_INDEX)):
            pc_pl, _, _ = MODEL.placeholder_inputs(BATCH_SIZE, NUM_POINT, NUM_INS)

            is_training_pl = tf.placeholder(tf.bool, shape=())
            
            mask_pred, conf_pred, _ = MODEL.get_model(pc_pl, NUM_INS, is_training_pl)

            loader = tf.train.Saver()
        
        # Create a session
        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True
        config.allow_soft_placement = True
        config.log_device_placement = False
        sess = tf.Session(config=config)

        # Load pretrained model
        ckptstate = tf.train.get_checkpoint_state(CKPT_DIR)
        if ckptstate is not None:
            LOAD_MODEL_FILE = os.path.join(CKPT_DIR, os.path.basename(ckptstate.model_checkpoint_path))
            loader.restore(sess, LOAD_MODEL_FILE)
            #print("Model loaded in file: %s" % LOAD_MODEL_FILE)
        else:
            #print("Fail to load modelfile: %s" % CKPT_DIR)
            assert False
            
        # Start testing

        pts = np.expand_dims(pts, 0)        
            
        feed_dict = {
            pc_pl: pts,
            is_training_pl: False
        }

        mask_pred_val, conf_pred_val = sess.run([mask_pred, conf_pred], feed_dict=feed_dict)
                
        mask_hard_val = (mask_pred_val >= MIN_POINT_SCORE)
        mask_valid_val = ((np.sum(mask_hard_val, axis=-1) >= MIN_NUM_POINTS))

        reg_pred = torch.from_numpy(mask_pred_val)[0]
        reg_valid = torch.from_numpy(mask_valid_val)[0]

        valid = reg_valid.nonzero().flatten()
        non_valid = (~reg_valid).nonzero().flatten()

        reg_pred[non_valid] = 0.

        reg_pred = reg_pred.T

        raw_preds = reg_pred.argmax(dim=1)

        preds = torch.zeros(raw_preds.shape[0]).long() - 1

        for i, v in enumerate(raw_preds.unique().tolist()):
            preds[(raw_preds == v).nonzero().flatten()] = i

        assert (preds >= 0).all()

        return preds

if __name__ == '__main__':
    pts = np.random.randn(10000, 3)
    pred_regions(sys.argv[1], pts)
