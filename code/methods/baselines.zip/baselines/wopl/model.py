import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import sys
sys.path.append('methods/wopl/')
from pn_enc import PNPP_PointEnc
import dgl.function as fn
import dgl

# Whether losses should be summed or meaned on a per-point basis
# Best guess is that averaging losses over points is better

DO_SUM = False
#DO_SUM = True

class MLP(nn.Module):
    def __init__(self, ind, hdim1, hdim2, odim):
        super(MLP, self).__init__()
        self.l1 = nn.Linear(ind, hdim1)
        self.l2 = nn.Linear(hdim1, hdim2)
        self.l3 = nn.Linear(hdim2, odim)

    def forward(self, x):
        x = F.leaky_relu(self.l1(x), 0.02)
        x = F.leaky_relu(self.l2(x), 0.02)
        return self.l3(x)


class SMLP(nn.Module):
    def __init__(self, idim, odim):
        super(SMLP, self).__init__()
        self.l1 = nn.Linear(idim, odim)
        self.l2 = nn.Linear(odim, odim)

    def forward(self, x):
        x = F.leaky_relu(self.l1(x), 0.02)        
        return self.l2(x)


class WOPL_PriorNet(nn.Module):
    def __init__(self, max_rank, k):
        super(WOPL_PriorNet, self).__init__()

        self.max_rank = max_rank
        self.K = k
        
        self.pnpp_enc = PNPP_PointEnc()
        self.lr_net = MLP(512, 256, 128, self.max_rank)
        
        
    # pc is B X N x 3
    def forward(self, pc):

        point_embs = self.pnpp_enc(pc)
        S_dist = ((point_embs.unsqueeze(1) - point_embs.unsqueeze(2)).abs() + 1e-8).norm(dim=3)
        S_sim = 1. / (1.+S_dist)

        
        S_lr = self.lr_net(S_sim)
        
        
        return S_sim, S_lr, S_dist, point_embs
    
    # regions is B X N matrix
    def loss(self, S_lr, S_dist, regions, rank):
        
        S_nlr = torch.softmax(S_lr[:,:,:rank], dim = 2)

        with torch.no_grad():
            S_gt = (regions.unsqueeze(1) == regions.unsqueeze(2)).float()
        
        S_elr = S_nlr @ S_nlr.transpose(1,2)    
        
        # Freb norm averaged over batch

        if DO_SUM:
        
            loss_lr = ((S_gt - S_elr) **2 + 1e-8).sum(dim=2).sum(dim=1).mean()
        
            loss_sim = (
                (S_gt * S_dist) + ((1. - S_gt) * torch.relu(self.K - S_dist))
            ).sum(dim=2).sum(dim=1).mean()

        else:
            
            loss_lr = ((S_gt - S_elr) **2 + 1e-8).mean()
        
            loss_sim = (
                (S_gt * S_dist) + ((1. - S_gt) * torch.relu(self.K - S_dist))
            ).mean()            
            
        return loss_lr, loss_sim


class WOPL_MergeNet(nn.Module):
    def __init__(self, max_rank, k):
        super(WOPL_MergeNet, self).__init__()

        self.gcn = GCNNet()
        self.max_rank = max_rank
        self.K = k

        # This needs to be set the maximum number of slots ever returned by the prior network over the entire shape
        # which to our best estimation is the number of slots by the number of blocks 
        
        self.max_pos = 5 * 7 * 7 * 7
        
        self.lr_net = MLP(self.max_pos, 512, 256, self.max_rank)
        
    # pc is B X N x 3
    def forward(self, bg, do_train):
        
        self.gcn(bg, bg.ndata['node_feats'])

        R_dist = []
        R_sim = []
        R_lr = []
        R_segs = []
        
        for g in dgl.unbatch(bg):
            
            reg_embs = g.ndata['node_pred']
            
            S_dist = ((reg_embs.unsqueeze(0) - reg_embs.unsqueeze(1)).abs() + 1e-8).norm(dim=2)
            S_sim = 1. / (1.+S_dist)            

            inp = torch.cat((S_sim, torch.zeros(S_sim.shape[0], self.max_pos - S_sim.shape[1], device=S_sim.device)), dim = 1)

            S_lr = self.lr_net(inp)            
            
            R_dist.append(S_dist)
            R_sim.append(S_sim)
            R_lr.append(S_lr)
            
            if do_train:
                R_segs.append(g.ndata['segments'])

        if do_train:                
            return R_sim, R_lr, R_dist, R_segs
        else:
            return R_sim, R_lr, R_dist
        
    # regions is B X N matrix
    def loss(self, R_lr, R_dist, R_segs):

        T_loss_lr = 0.
        T_loss_sim = 0.
        T_count = 1e-8
        
        for S_lr, S_dist, regions in zip(R_lr, R_dist, R_segs):            
            rank = regions.unique().shape[0]        
            S_nlr = torch.softmax(S_lr[:,:rank], dim = 1)
                                
            with torch.no_grad():
                S_gt = (regions.unsqueeze(0) == regions.unsqueeze(1)).float()
                                                                                
            S_elr = S_nlr @ S_nlr.transpose(0,1)    
                    
            loss_lr = ((S_gt - S_elr) **2 + 1e-8).mean()
            
            loss_sim = (
                (S_gt * S_dist) + ((1. - S_gt) * torch.relu(self.K - S_dist))
            ).mean()

            T_loss_lr += loss_lr
            T_loss_sim += loss_sim 
            T_count += 1.
            
        return T_loss_lr / T_count, T_loss_sim / T_count

class GCNNet(nn.Module):

    def __init__(self, dim = 128, n_layers = 3):
        super(GCNNet, self).__init__()
                                                               
        self.layers = nn.ModuleList([GCNLayer(dim) for _ in range(n_layers)])
                        
    def forward(self, g, h):
        
        # GCN
        for conv in self.layers:
            h = conv(g, h)            
            
        g.ndata['node_pred'] = h


msg = fn.copy_src(src='h', out='m')
    
def reduce(nodes):
    accum = torch.mean(nodes.mailbox['m'], 1)
    return {'adj': accum}


class NodeApplyModule(nn.Module):
    # Update node feature h_v with (Wh_v+b)
    def __init__(self, dim):
        super(NodeApplyModule, self).__init__()
        self.ll2 = SMLP(dim+dim, dim)
        
    def forward(self, node):        
        h = self.ll2(
            torch.cat((
                node.data['oh'],
                node.data['adj']
            ), dim=1)
        )        
        return {'o': h}
    
    
class GCNLayer(nn.Module):
              
    def __init__(self, dim):
        super(GCNLayer, self).__init__()                
        self.apply_mod = NodeApplyModule(dim)                
        self.ll1 = SMLP(dim, dim)
        
    def forward(self, g, feature):
        
        g.ndata['oh'] = feature
        g.ndata['h'] = self.ll1(feature)
        
        g.update_all(msg, reduce)
        
        g.apply_nodes(func=self.apply_mod)
        
        h = g.ndata['o'] # result of graph convolution
        
        return h
