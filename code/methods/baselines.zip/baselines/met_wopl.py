import sys, os, torch
import numpy as np
import utils
import train_utils
from utils import device
from copy import deepcopy
import random
from tqdm import tqdm
from methods.wopl.model import WOPL_PriorNet, WOPL_MergeNet
import math
import dgl
        
TRAIN_LOG_INFO = [
    ('Loss', 'loss', 'batch_count'),
    ('Loss Sim', 'loss_sim', 'batch_count'),
    ('Loss LR', 'loss_lr', 'batch_count'),
    ('Num Reg', 'num_reg', 'batch_count'),
]

class Block:
    def __init__(self):
        pass

def split_to_blocks(
    regions, part_ids, num_points, num_points_per_block, num_blocks
):

    # Training
    if part_ids is not None:
        try:
            _, gpu_samps, _, gpu_segments = utils.train_sample(
                regions,
                part_ids,
                num_points=num_points        
            )
            samps = gpu_samps.cpu()
            segments = gpu_segments.cpu()
            
        except Exception as e:
            print(f"Error in sampling {e}")
            return []
            
    # Eval
    else:
        assert len(regions) == 2
        samps, _, _ = utils.sample_surface(regions[1], regions[0].unsqueeze(0), num_points)
        
    blocks = []

    Smin = torch.clamp(samps.min(dim=0).values,-10., -1.)
    Smax = torch.clamp(samps.max(dim=0).values,1., 10.)
                        
    divs = [i*1. / (num_blocks) for i in range(num_blocks,-1,-1)]
    
    for i in range(num_blocks):
        for j in range(num_blocks):
            for k in range(num_blocks):

                min_corner = (Smin * torch.tensor([
                    divs[i],
                    divs[j],
                    divs[k],
                ], device=samps.device)) + \
                (Smax * torch.tensor([
                    1. - divs[i],
                    1. - divs[j],
                    1. - divs[k],
                ], device=samps.device))

                max_corner = (Smin * torch.tensor([
                    divs[i+1],
                    divs[j+1],
                    divs[k+1],
                ], device=samps.device)) + \
                (Smax * torch.tensor([
                    1. - divs[i+1],
                    1. - divs[j+1],
                    1. - divs[k+1],
                ], device=samps.device))
                
                raw_in_pts = (
                    ((samps - min_corner.unsqueeze(0)) >= 0.).all(dim=1) & \
                    ((samps - max_corner.unsqueeze(0)) <= 0.).all(dim=1)
                )
                
                in_pts = raw_in_pts.nonzero().flatten()

                if in_pts.shape[0] == 0:
                    continue

                in_pts, _ = utils.shrink_inds(in_pts, num_points_per_block)
                
                blk_samps = utils.normalize(samps[in_pts])

                b = Block()
                
                b.blk_samps = blk_samps
                b.orig_samps = samps[in_pts]
                
                if part_ids is not None:
                    b.num_segments = segments[in_pts].unique().shape[0]
                    b.blk_segments = segments[in_pts]
                else:
                    b.blk_segments = None

                blocks.append(b)
                    
    return blocks

def check_aabb_intersect(Amin, Amax, Bmin, Bmax, thresh):
    v = (Amin[0] <= (Bmax[0] + thresh)) &\
        (Bmin[0] <= (Amax[0] + thresh)) &\
        (Amin[1] <= (Bmax[1] + thresh)) &\
        (Bmin[1] <= (Amax[1] + thresh)) &\
        (Amin[2] <= (Bmax[2] + thresh)) &\
        (Bmin[2] <= (Amax[2] + thresh))

    return v.item()
    
def find_edges(nodes):
    src = []
    dst = []

    for i, n in enumerate(nodes):
        for j, m in enumerate(nodes):
            if i >= j:
                continue


            if not check_aabb_intersect(
                n.min_c,
                n.max_c,
                m.min_c,
                m.max_c,
                0.001
            ):
                continue

            src.append(i)
            src.append(j)
            
            dst.append(j)            
            dst.append(i)

    return src, dst
            
def make_merge_graph(
    prior_net, regions, part_ids, num_points, num_points_per_block,
    num_blocks, max_merge_rank, max_prior_rank
):
    blocks = split_to_blocks(
        regions, part_ids, num_points,
        num_points_per_block, num_blocks
    )

    if len(blocks) == 0:
        return None
    
    node_list = []
    
    for block in blocks:

        samps, orig_samps = block.blk_samps, block.orig_samps
                
        segments = block.blk_segments

        samps = samps.to(device).unsqueeze(0)
        S_sim, S_lr, _, S_emb = prior_net(samps)        
        
        raw_pred_regions = low_rank_make_split(S_sim, S_lr, max_prior_rank)

        pred_regions = utils.clean_regions(raw_pred_regions, max_prior_rank)
        
        for i in pred_regions.unique():
            node = Block()
            inds = (pred_regions == i).nonzero().flatten()        
            node.feat = S_emb[0,inds].max(dim=0).values.cpu()
            node.samps = orig_samps[inds].cpu()
            node.min_c = node.samps.min(dim=0).values
            node.max_c = node.samps.max(dim=0).values
            
            if segments is not None:
                node.segment = segments[inds].mode().values.cpu().item()
                
            node_list.append(node)

            
    src, dst = find_edges(node_list)    
    
    g = dgl.DGLGraph()
    g.add_nodes(len(node_list))
    g.add_edges(src, dst)
    g.ndata['node_feats'] = torch.stack([n.feat for n in node_list], dim=0)
    
    if part_ids is not None:
        g.ndata['segments'] = torch.tensor([n.segment for n in node_list]).long() 
        return g
    else:
        return g, node_list
                
    

class MergeDataset:
    def __init__(
        self,
        data,
        prior_net,
        batch_size,
        num_points,
        num_points_per_block,
        num_blocks,
        max_merge_rank,
        max_prior_rank
    ):
                        
        self.max_merge_rank = max_merge_rank

        self.graphs = []
        
        for d in tqdm(data):
            with torch.no_grad():
                g = make_merge_graph(
                    prior_net, d.regions, d.part_ids, num_points, num_points_per_block,
                    num_blocks, max_merge_rank, max_prior_rank
                )

                if g is None:
                    continue
                
                self.graphs.append(g)

        self.batch_size = batch_size

    def __iter__(self):

        inds = torch.randperm(len(self.graphs))

        for start in range(0, inds.shape[0], self.batch_size):
            binds = inds[start:start+self.batch_size]

            bgraphs = [self.graphs[bi] for bi in binds]
            
            batch_graph = dgl.batch(bgraphs)

            batch_graph = batch_graph.to(device)            
            
            yield batch_graph
        

class Dataset:
    def __init__(
        self, data, batch_size, num_points, num_points_per_block,
        num_blocks, max_prior_rank
    ):
                
        self.data_map = {}        
        self.max_prior_rank = max_prior_rank
        
        for d in tqdm(data):
            
            with torch.no_grad():
                blocks = split_to_blocks(
                    d.regions, d.part_ids, num_points,
                    num_points_per_block, num_blocks
                )

                for block in blocks:

                    rank, samps, segments = \
                        block.num_segments, block.blk_samps, block.blk_segments
                    
                    if rank > max_prior_rank:
                        continue
                    
                    if rank not in self.data_map:
                        self.data_map[rank] = {'samps': [], 'segments': []}
                                           
                    n_samps = samps.numpy().astype('float16')
                    n_segments = segments.numpy().astype('int16')

                    self.data_map[rank]['samps'].append(n_samps)
                    self.data_map[rank]['segments'].append(n_segments)
                            
        for rank in self.data_map:
            self.data_map[rank]['samps'] = np.stack(self.data_map[rank]['samps'])
            self.data_map[rank]['segments'] = np.stack(self.data_map[rank]['segments'])
            
        self.batch_size = batch_size


        
    def __iter__(self):
        yield from self.prior_yield()

        
    def prior_yield(self):
        # balanced ranks, yield batch from each rank

        rank_inds = {}

        min_seen = 1e8
        
        for rank in range(1, self.max_prior_rank+1):
            num_seen = self.data_map[rank]['segments'].shape[0]

            min_seen = min(min_seen, num_seen)
            
            rank_inds[rank] = torch.randperm(num_seen).numpy()

        batch_list = []

        for r in rank_inds.keys():
            start = 0

            while start < min_seen:
                batch_list.append((r, start, min(start+self.batch_size, min_seen)))
                start += self.batch_size
                
        random.shuffle(batch_list)

        for rank, start, end in batch_list:
        
            with torch.no_grad():

                binds = rank_inds[r][start:end]
                
                b_samps = torch.from_numpy(self.data_map[rank]['samps'][binds]).float().to(device)
                b_segments = torch.from_numpy(self.data_map[rank]['segments'][binds]).long().to(device)
                                        
                
            yield rank, b_samps, b_segments

def low_rank_make_split(S_sim, S_lr, max_prior_rank):

    preds = None
    best_loss = 1e8
    
    for rank in range(1, max_prior_rank+1):

        S_nlr = torch.softmax(S_lr[:,:,:rank], dim = 2)        
        S_elr = S_nlr @ S_nlr.transpose(1,2)
        
        loss = ((S_sim - S_elr) ** 2).mean().item()
        
        if loss < best_loss:
            best_loss = loss
            preds = S_lr[0,:,:rank].argmax(dim=1)
            
    return preds.cpu()
            
def prior_model_split(net, mesh, args):
            
    blocks = split_to_blocks(
        mesh, None, args.num_points,
        args.num_points_per_block, args.num_blocks
    )

    big_samps = []
    big_regions = []

    offset = 0
    
    for block in blocks:

        orig_samps, samps = block.orig_samps, block.blk_samps
        
        samps = samps.to(device).unsqueeze(0)
        S_sim, S_lr, _, _ = net(samps)
        
        raw_pred_regions = low_rank_make_split(S_sim, S_lr, args.max_prior_rank)

        pred_regions = utils.clean_regions(raw_pred_regions, args.max_prior_rank)
        
        big_samps.append(orig_samps)
        big_regions.append(pred_regions + offset)

        num_regions = pred_regions.unique().shape[0]
        
        offset += num_regions
                
    big_samps = torch.cat(big_samps, dim = 0).cpu()
    big_regions = torch.cat(big_regions, dim = 0).cpu()
    
    return big_samps, big_regions


def merge_model_split(prior_net, merge_net, mesh, args):
            
    g, node_list = make_merge_graph(
        prior_net, mesh, None, args.num_points,                               
        args.num_points_per_block, args.num_blocks,
        args.max_merge_rank, args.max_prior_rank
    )
    
    bg = dgl.batch([g])
    
    bg = bg.to(device)

    R_sim, R_lr, R_dist = merge_net(bg, False)

    S_sim, S_lr, S_dist = R_sim[0], R_lr[0], R_dist[0]
        
    raw_pred_regions = low_rank_make_split(
        S_sim.unsqueeze(0), S_lr.unsqueeze(0), args.max_merge_rank
    )
    
    pred_regions = utils.clean_regions(raw_pred_regions, args.max_merge_rank)

    big_samps = []
    big_regions = []
    
    for node, pred in zip(node_list, pred_regions):
        big_samps.append(node.samps)
        big_regions.append(torch.ones(node.samps.shape[0]).long() * pred)
        
    big_samps = torch.cat(big_samps, dim = 0).cpu()
    big_regions = torch.cat(big_regions, dim = 0).cpu()
    
    return big_samps, big_regions
            
def prior_model_train_batch(batch, net, opt):
    rank, samps, segments = batch
    
    br = {}

    S_sim, S_lr, S_dist, _ = net(samps)

    loss_lr, loss_sim = net.loss(S_lr, S_dist, segments, rank)

    loss = loss_lr + loss_sim            

    if opt is not None:
        opt.zero_grad()
        loss.backward()
        opt.step()

    br['loss'] = loss.item()
    br['loss_lr'] = loss_lr.item()
    br['loss_sim'] = loss_sim.item()        
    
    return br

def merge_model_train_batch(batch, net, opt):
    bg = batch
    br = {}
    
    R_sim, R_lr, R_dist, R_segs = net(bg, True)

    loss_lr, loss_sim = net.loss(R_lr, R_dist, R_segs)

    loss = loss_lr + loss_sim            

    if opt is not None:
        opt.zero_grad()
        loss.backward()
        opt.step()

    br['loss'] = loss.item()
    br['loss_lr'] = loss_lr.item()
    br['loss_sim'] = loss_sim.item()
    with torch.no_grad():
        br['num_reg'] = torch.tensor(
            [S_lr.argmax(dim=1).unique().shape[0] for S_lr in R_lr]
        ).float().mean().item()
    
    return br
    
def train_wopl_prior(args, train_data, val_data):
    
    utils.init_model_run(args, 'wopl_prior')
                    
    print(f"Num training data {len(train_data)}")
    print(f"Num val data {len(val_data)}")
        
    train_loader = Dataset(
        train_data,
        args.prior_batch_size,
        args.num_points,
        args.num_points_per_block,
        args.num_blocks,
        args.max_prior_rank
    )

    val_loader = Dataset(
        val_data,
        args.prior_batch_size,
        args.num_points,
        args.num_points_per_block,
        args.num_blocks,
        args.max_prior_rank
    )        
    
    net = WOPL_PriorNet(args.max_prior_rank, args.k)        
    net.to(device)
    
    opt = torch.optim.Adam(
        net.parameters(),
        lr = args.lr,
        eps = 1e-6
    )
        
    res = {
        'train_plots': {'train':{}, 'val':{}},
        'train_epochs': [],
    }

    save_model_weights = None

    best_ep = 0.
    best_loss = 1e8
    
    for e in range(args.epochs):
        
        train_utils.run_train_epoch(
            args,
            res,
            net,
            opt,
            train_loader,
            val_loader,
            TRAIN_LOG_INFO,
            e,
            prior_model_train_batch
        )

        val_loss = res['train_plots']['val']['Loss'][-1]
                    
        if val_loss + args.es_threshold < best_loss:
            best_loss = val_loss
            best_ep = e
            save_model_weights = deepcopy(net.state_dict())
            torch.save(
                save_model_weights,
                f"{args.outpath}/{args.exp_name}/models/prior_net.pt"
            )
            
        if (e - best_ep) > args.es_patience:
            utils.log_print("Stopping Early", args)
            break


def train_wopl_merge(args, train_data, val_data, prior_net):
    
    utils.init_model_run(args, 'wopl_merge')
                    
    print(f"Num training data {len(train_data)}")
    print(f"Num val data {len(val_data)}")
        
    train_loader = MergeDataset(
        train_data,
        prior_net,
        args.merge_batch_size,
        args.num_points,
        args.num_points_per_block,
        args.num_blocks,
        args.max_merge_rank,
        args.max_prior_rank
    )

    val_loader = MergeDataset(
        val_data,
        prior_net,
        args.merge_batch_size,
        args.num_points,
        args.num_points_per_block,
        args.num_blocks,
        args.max_merge_rank,
        args.max_prior_rank
    )        
    
    net = WOPL_MergeNet(args.max_merge_rank, args.k)
    net.to(device)
    
    opt = torch.optim.Adam(
        net.parameters(),
        lr = args.lr,
        eps = 1e-6
    )
        
    res = {
        'train_plots': {'train':{}, 'val':{}},
        'train_epochs': [],
    }

    save_model_weights = None

    best_ep = 0.
    best_loss = 1e8
    
    for e in range(args.epochs):
        
        train_utils.run_train_epoch(
            args,
            res,
            net,
            opt,
            train_loader,
            val_loader,
            TRAIN_LOG_INFO,
            e,
            merge_model_train_batch
        )
        
        val_loss = res['train_plots']['val']['Loss'][-1]
                    
        if val_loss + args.es_threshold < best_loss:
            best_loss = val_loss
            best_ep = e
            save_model_weights = deepcopy(net.state_dict())
            torch.save(
                save_model_weights,
                f"{args.outpath}/{args.exp_name}/models/merge_net.pt"
            )
            
        if (e - best_ep) > args.es_patience:
            utils.log_print("Stopping Early", args)
            break
    
class WOPL:
    def __init__(self):
        self.name = 'wopl'
        self.net = None        

        arg_list = [
            ('-o', '--outpath', 'methods/wopl/model_output', str),
            ('-en', '--exp_name', None, str),
            ('-np', '--num_points', 100000, int),
            ('-nppb', '--num_points_per_block', 512, int),
            ('-nb', '--num_blocks', 7, int),
            ('-rd', '--rd_seed', 42, int),
            ('-pbs', '--prior_batch_size', 24, int),
            ('-mbs', '--merge_batch_size', 4, int),
            ('-e', '--epochs', 1000, int),
            ('-lr', '--lr', 0.0001, float),
            ('-prp', '--print_per', 1, int),
            ('-esp', '--es_patience', 50, int),
            ('-est', '--es_threshold', 0.01, float),

            ('-mpr', '--max_prior_rank', 5, int),
            ('-mmr', '--max_merge_rank', 100, int),
            ('-k', '--k', 100, int),

            ('-pn_pth', '--prior_net_path', None, str),
            ('-mn_pth', '--merge_net_path', None, str),
            ('-wm', '--wopl_mode', None, str),
        ]
        
        args = utils.getArgs(arg_list)

        assert args.wopl_mode in ['prior', 'merge']
        
        self.args = args
        
        if args.prior_net_path is not None:
            print("Loading Prior Net")
            net = WOPL_PriorNet(args.max_prior_rank, args.k)
            net.eval()
            net.load_state_dict(torch.load(
                args.prior_net_path
            ))
            net.to(device)
            
            self.prior_net = net

        if args.merge_net_path is not None:
            print("Loading Merge Net")
            net = WOPL_MergeNet(args.max_merge_rank, args.k)
            net.eval()
            net.load_state_dict(torch.load(
                args.merge_net_path
            ))
            net.to(device)
            
            self.merge_net = net
                    
    def make_pred(self, data):

        args = self.args

        if args.wopl_mode == 'prior':
            big_samps, big_regions = prior_model_split(self.prior_net, data.mesh, args)

        elif args.wopl_mode == 'merge':
            big_samps, big_regions = merge_model_split(
                self.prior_net,
                self.merge_net,
                data.mesh,
                args
            )
        
        regions = utils.pcsearch.do_search(
            data.points,
            big_samps,
            big_regions
        )
        
        return regions

    def train(self, train_data, val_data, save_name):


        if self.args.wopl_mode == 'prior':
        
            print(f"Training WOPL Prior")
            train_wopl_prior(self.args, train_data, val_data)

        elif self.args.wopl_mode == 'merge':

            assert self.prior_net is not None
            
            print(f"Training WOPL Merge")
            train_wopl_merge(self.args, train_data, val_data, self.prior_net)

        else:
            assert False, f'bad mode {self.args.wopl_mode}'
