import numpy as np
import os
import h5py
import utils
from tqdm import tqdm
import torch
from methods.pn_seg.ins_seg_detection.test_eval import pred_regions
import sys

def save_h5(fn, pts, gt_mask, gt_valid):
    fout = h5py.File(fn, 'w')
    fout.create_dataset('pts', data=pts, compression='gzip', compression_opts=4, dtype='float32')
    fout.create_dataset('gt_mask', data=gt_mask, compression='gzip', compression_opts=4, dtype='bool')
    fout.create_dataset('gt_valid', data=gt_valid, compression='gzip', compression_opts=4, dtype='bool')
    fout.close()

def make_data(args, d):
    
    NUM_POINT = args.num_points
    NUM_INS = args.num_ins
    
    _, gpu_pts, _, gpu_part_ids = utils.train_sample(d.regions, d.part_ids)

    pts = gpu_pts.cpu()
    part_ids = gpu_part_ids.cpu()    
    
    mask = np.zeros((NUM_INS, NUM_POINT)).astype(np.bool)
    valid = np.zeros((NUM_INS)).astype(np.bool) 

    seen = part_ids.cpu().unique().tolist()
    seen.sort()

    for i,j in enumerate(seen[:NUM_INS]):
        valid[i] = True
        mask[i, (part_ids == j).nonzero().flatten().numpy()] = True

    return pts.numpy(), mask, valid
    
def write_data(args, data, name):

    NUM_POINT = args.num_points
    NUM_INS = args.num_ins
    
    n_shape = len(data)
    
    r_pts = np.zeros((n_shape, NUM_POINT, 3), dtype = np.float32)    
    r_mask = np.zeros((n_shape, NUM_INS, NUM_POINT), dtype = np.bool)
    r_valid = np.zeros((n_shape, NUM_INS), dtype = np.bool)

    print("Writing Data")

    i = 0
    
    for d in tqdm(data):

        try:
            _pts, _mask, _valid = make_data(args, d)
        except Exception as e:
            print(f"Failed make_data with {e}")
            continue
            
        r_pts[i] = _pts
        r_mask[i] = _mask
        r_valid[i] = _valid

        i += 1
        
    save_h5(name, r_pts[:i+1], r_mask[:i+1], r_valid[:i+1])

class PN_SEG:
    def __init__(self):
        self.name = 'pn_seg'
        arg_list = [
            ('-pnd', '--pnd', 'methods/pn_seg/ins_seg_detection/', str),
            ('-o', '--outpath', 'model_output', str),
            ('-en', '--exp_name', None, str),
            ('-np', '--num_points', 10000, int),
            ('-ni', '--num_ins', 200, int),
        ]

        self.args = utils.getArgs(arg_list)
        
    def make_pred(self, data):
        args = self.args
        model_path = f'{args.pnd}/{args.outpath}/{args.exp_name}'
        
        with utils.SuppressStream():        
            preds = pred_regions(model_path, data.points.numpy())
        
        return preds

    def train_script(self):
        args = self.args
        lines = [
            f'cd {args.pnd}/',
            f'python3 train.py -dp {args.outpath}/{args.exp_name} --num_point {args.num_points} --num_ins {args.num_ins}'
        ]
        print("Training PN SEG with")

        script_name = f'{args.pnd}/{args.outpath}/{args.exp_name}/run_train.sh'

        with open(script_name, 'w') as f:        
            for line in lines:
                print(line)
                f.write(line + '\n')
        
        os.system(f'sh {script_name}')
        
    def train(self, train_data, val_data, save_name):
        args = self.args
        
        os.system(f'rm {args.pnd}/{args.outpath}/{args.exp_name}/ -r')
        
        os.system(f'mkdir {args.pnd}/{args.outpath}/{args.exp_name} ')
        
        write_data(args, train_data, f'{args.pnd}/{args.outpath}/{args.exp_name}/train.h5')
        write_data(args, val_data, f'{args.pnd}/{args.outpath}/{args.exp_name}/val.h5')

        self.train_script()                        

        os.system(f'rm -f {args.pnd}/{args.outpath}/{args.exp_name}/*.h5')
