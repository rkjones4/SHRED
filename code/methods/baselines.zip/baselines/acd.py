import pybullet as p
import utils
import os, sys
import numpy as np
import torch
sys.path.append('..')
sys.path.append('../..') 
import utils
import time
from tqdm import tqdm
import json
import faiss
import pickle

TMP_DIR = f'tmp'
CACHE_DIR = f'cache/acd'

os.system(f'mkdir {TMP_DIR} > /dev/null 2>&1')
os.system(f'mkdir {CACHE_DIR} > /dev/null 2>&1')

class SuppressStream(object): 

    def __init__(self, stream=sys.stderr):
        self.orig_stream_fileno = stream.fileno()

    def __enter__(self):
        self.orig_stream_dup = os.dup(self.orig_stream_fileno)
        self.devnull = open(os.devnull, 'w')
        os.dup2(self.devnull.fileno(), self.orig_stream_fileno)

    def __exit__(self, type, value, traceback):
        os.close(self.orig_stream_fileno)
        os.dup2(self.orig_stream_dup, self.orig_stream_fileno)
        os.close(self.orig_stream_dup)
        self.devnull.close()

            
def loadObjByGroup(infile):
    tverts = []
    ttris = []
    comps = []
    
    gcount = 0
    
    with open(infile) as f:
        
        for line in f:
            ls = line.split()
            if len(ls) == 0:
                continue
            
            if ls[0] == 'o':
                gcount += 1                
                
            elif ls[0] == 'v':
                tverts.append([
                    float(ls[1]),
                    float(ls[2]),
                    float(ls[3])
                ])
                
            elif ls[0] == 'f':
                ttris.append([
                    int(ls[1].split('//')[0]) - 1,
                    int(ls[2].split('//')[0]) - 1,
                    int(ls[3].split('//')[0]) - 1
                ])
                comps.append(gcount)
                
    return tverts, ttris, comps

                
def do_vhacd(in_name):
    out_name = f'{TMP_DIR}/acd_out.obj'
    with SuppressStream(sys.stdout):
        p.vhacd(
	    in_name,
	    out_name,
	    '{TMP_DIR}/log.txt',
            resolution = 100000,
            depth = 20,
            concavity = 0.0025,
            planeDownsampling = 4,                
	    convexhullDownsampling = 4,
            alpha = .05,
            beta = 0.05,
            gamma = .00125,
            maxNumVerticesPerCH =  64,
            minVolumePerCH = 0.0001,
        )

    groups = loadObjByGroup(out_name)

    return groups
        
def run_acd(mesh, ind):
    fls = os.listdir(CACHE_DIR)

    if f'{ind}.pkl' in fls:
        res = pickle.load(open(f'{CACHE_DIR}/{ind}.pkl', 'rb'))
    else:
        res = _run_acd(mesh)
        pickle.dump(res, open(f'{CACHE_DIR}/{ind}.pkl', 'wb'))
        
    return res

def _run_acd(mesh):
    
    raw_name = f'{TMP_DIR}/input.obj'

    utils.writeObj(mesh[0], mesh[1], raw_name)
    
    os.system(f'manifold {raw_name} {raw_name} 200000 > /dev/null 2>&1')
     
    groups = do_vhacd(raw_name)            

    return groups
            
def getACDRegions(samps, acd_data):
    
    verts, faces, comps = acd_data

    verts = torch.tensor(verts).float()
    faces = torch.tensor(faces).long()
    comps = torch.tensor(comps).long()
    
    d_samps, d_inds, d_norms = utils.sample_surface(
        faces,
        verts.unsqueeze(0),
        100000
    )

    d_comps = comps[d_inds]
    r_comps = utils.pcsearch.do_search(samps, d_samps, d_comps)

    return r_comps
    
class ACD:
    def __init__(self):
        self.name = 'acd'

    def make_pred(self, data):
        acd_groups = run_acd(data.mesh, data.ind)
        regions = getACDRegions(data.points, acd_groups)
        
        return regions
