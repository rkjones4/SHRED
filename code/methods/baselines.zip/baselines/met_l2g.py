import os, torch
import numpy as np
import h5py
from tqdm import tqdm
import utils

NUM_POINT = 10000
NUM_INS = 200

def save_h5(fn, pts, gt_mask, gt_valid):
    fout = h5py.File(fn, 'w')
    fout.create_dataset('pts', data=pts, compression='gzip', compression_opts=4, dtype='float32')
    fout.create_dataset('gt_mask', data=gt_mask, compression='gzip', compression_opts=4, dtype='bool')
    fout.create_dataset('gt_valid', data=gt_valid, compression='gzip', compression_opts=4, dtype='bool')
    fout.close()

def make_data(d):
            
    pts = d.points.cpu()
    part_ids = utils.clean_regions(d.EVAL_part_ids.cpu())
    
    mask = np.zeros((NUM_INS, NUM_POINT)).astype(np.bool)
    valid = np.zeros((NUM_INS)).astype(np.bool) 

    seen = part_ids.cpu().unique().tolist()
    seen.sort()

    for i,j in enumerate(seen[:NUM_INS]):
        valid[i] = True
        mask[i, (part_ids == j).nonzero().flatten().numpy()] = True

    return pts.numpy(), mask, valid
    
class L2GSave:
    def __init__(self):
        self.name = 'l2g_save'

    def save_data(self, data, fn):
        os.system(f'mkdir {fn} > /dev/null 2>&1')
        os.system(f'mkdir {fn}/train_data/ > /dev/null 2>&1')

        n_shape = len(data)        
        
        r_pts = np.zeros((n_shape, NUM_POINT, 3), dtype = np.float32)    
        r_mask = np.zeros((n_shape, NUM_INS, NUM_POINT), dtype = np.bool)
        r_valid = np.zeros((n_shape, NUM_INS), dtype = np.bool)

        i = 0

        name = f'{fn}/train_data/test.h5'
        
        for d in tqdm(data):
            _pts, _mask, _valid = make_data(d)

            r_pts[i] = _pts
            r_mask[i] = _mask
            r_valid[i] = _valid

            i += 1

        assert i == n_shape
            
        save_h5(name, r_pts, r_mask, r_valid)


class L2GLoad:
    def __init__(self):
        self.name = 'l2g_load'

        arg_list = [
            ('-ld', '--load_dir', None, str),
            ('-vd', '--val_dir', 'l2g_eval_data', str),
            ('-pt', '--pred_type', 'merge', str),
        ]

        args = utils.getArgs(arg_list)

        assert args.load_dir is not None
        assert args.pred_type in ['split', 'merge']
        self.args = args

        self.pred_regs = {}
        
    def make_pred(self, data):

        args = self.args
        
        cat = data.cat

        if cat not in self.pred_regs:
            
            val_pts = torch.from_numpy(h5py.File(f'{args.val_dir}/{cat}/train_data/test.h5', 'r')['pts'][:]).float()
            pred_pts = torch.load(f'{args.load_dir}/{cat}/point.pt').float()

            self.pred_regs[cat] = torch.load(f'{args.load_dir}/{cat}/{args.pred_type}.pt').long()

            # Assert that evaluation points were loaded correctly
            
            def normalize_points(points):
                assert points.dim() == 3 and points.size(2) == 3
                centroid = points.mean(dim=1, keepdim=True)
                points = points - centroid
                norm, _ = points.norm(dim=2, keepdim=True).max(dim=1, keepdim=True)
                new_points = points / norm
                return new_points

            nval_pts = normalize_points(val_pts)
            
            assert ((nval_pts - pred_pts).abs() < 0.001).all()
                                                               
        dind = data.count_ind

        return self.pred_regs[cat][dind]
        
